<?php

/* XRealmAppBundle:Includes:base_layout.html.twig */
class __TwigTemplate_fc9acc18a879652e8fcd88d0db2bcf61e8f74d5b3eee4b9305976057051881e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html>
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width; initial-scale=1.0;\" />
  <link rel=\"stylesheet\" href=\"/styles/styles.css\">
  <link href='http://fonts.googleapis.com/css?family=Roboto:700,400' rel='stylesheet' type='text/css'>
  <title>";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("website.title"), "html", null, true);
        echo "</title>
</head>
<body>
\t<div id=\"page\">
\t\t<div id=\"header\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"row\">
\t\t\t\t\t<div class=\"col-sm-6\">
\t\t\t\t\t\t<div id=\"logo\">
\t\t\t\t\t\t\t<a href=\"";
        // line 17
        echo $this->env->getExtension('routing')->getPath("index");
        echo "\"><img src=\"/images/logo.png\" /></a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col-sm-6\">
\t\t\t\t\t\t<div id=\"user\">
\t\t\t\t\t\t\t";
        // line 22
        if ($this->env->getExtension('security')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 23
            echo "\t\t\t\t\t\t\t\t";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
            echo "
\t\t\t\t\t\t\t";
        } else {
            // line 25
            echo "\t\t\t\t\t\t\t\t<a id=\"loginbtn\" href=\"";
            echo $this->env->getExtension('routing')->getPath("login");
            echo "\" class=\"btn btn-info\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("website.login_register"), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t";
        }
        // line 27
        echo "\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<div id=\"navigation\">
\t\t\t<div class=\"container\">
\t\t\t";
        // line 34
        $this->env->loadTemplate("XRealmAppBundle:Includes:navigation.html.twig")->display($context);
        // line 35
        echo "\t\t\t</div>
\t\t</div>
\t\t<div id=\"content\">
\t\t\t<div class=\"container\">
\t\t\t";
        // line 39
        $this->displayBlock('content', $context, $blocks);
        // line 41
        echo "\t\t\t</div>
\t\t</div>
\t\t<div id=\"footer\">
\t\t\t<div class=\"container\">
\t\t\t";
        // line 45
        $this->env->loadTemplate("XRealmAppBundle:Includes:footer_navigation.html.twig")->display($context);
        // line 46
        echo "\t\t\t</div>
\t\t</div>
\t</div>
</body>
</html>";
    }

    // line 39
    public function block_content($context, array $blocks = array())
    {
        // line 40
        echo "\t\t\t";
    }

    public function getTemplateName()
    {
        return "XRealmAppBundle:Includes:base_layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 40,  100 => 39,  92 => 46,  90 => 45,  84 => 41,  82 => 39,  76 => 35,  74 => 34,  65 => 27,  57 => 25,  51 => 23,  49 => 22,  41 => 17,  29 => 8,  20 => 1,);
    }
}
