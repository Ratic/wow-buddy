<?php

/* XRealmAppBundle:Includes:navigation.html.twig */
class __TwigTemplate_4d6db011e625dcf0e2341629518236bf2e5badab02f2ce34ea84c6d7867aba7a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<ul id=\"nav\">
\t<li class=\"element\"><a href=\"#\">Navigation 1</a></li>
\t<li class=\"element\"><a href=\"#\">Navigation 2</a></li>
\t<li class=\"element\"><a href=\"#\">Navigation 3</a></li>
\t<li class=\"element\"><a href=\"#\">Navigation 4</a></li>
\t<li class=\"element\"><a href=\"#\">Navigation 5</a></li>

</ul>";
    }

    public function getTemplateName()
    {
        return "XRealmAppBundle:Includes:navigation.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
