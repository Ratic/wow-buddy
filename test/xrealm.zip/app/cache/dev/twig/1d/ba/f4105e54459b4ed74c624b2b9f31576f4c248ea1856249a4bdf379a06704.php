<?php

/* XRealmAppBundle:Includes:footer_navigation.html.twig */
class __TwigTemplate_1dbaf4105e54459b4ed74c624b2b9f31576f4c248ea1856249a4bdf379a06704 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"row\">
\t<div class=\"col-sm-3\">
\t\t<strong>Über XRealm</strong>
\t\t<ul>
\t\t\t<li><a href=\"#\">Team</a></li>
\t\t\t<li><a href=\"#\">Unterstütze uns</a></li>
\t\t\t<li><a href=\"#\">Impressum</a></li>
\t\t\t<li><a href=\"#\">Kontakt</a></li>
\t\t</ul>
\t</div>
\t<div class=\"col-sm-3\">
\t\t<strong>Übersicht</strong>
\t\t<ul>
\t\t\t<li><a href=\"#\">Kalender</a></li>
\t\t\t<li><a href=\"#\">Charaktersuche</a></li>
\t\t\t<li><a href=\"#\">Placeholder</a></li>
\t\t\t<li><a href=\"#\">Placeholder</a></li>
\t\t</ul>
\t</div>
\t<div class=\"col-sm-3\">
\t\t<strong>Placeholder</strong>
\t\t<ul>
\t\t\t<li><a href=\"#\">Placeholder</a></li>
\t\t\t<li><a href=\"#\">Placeholder</a></li>
\t\t\t<li><a href=\"#\">Placeholder</a></li>
\t\t\t<li><a href=\"#\">Placeholder</a></li>
\t\t</ul>
\t</div>
\t<div class=\"col-sm-3\">
\t\t<strong>Placeholder</strong>
\t\t<ul>
\t\t\t<li><a href=\"#\">Placeholder</a></li>
\t\t\t<li><a href=\"#\">Placeholder</a></li>
\t\t\t<li><a href=\"#\">Placeholder</a></li>
\t\t\t<li><a href=\"#\">Placeholder</a></li>
\t\t</ul>
\t</div>
</div>";
    }

    public function getTemplateName()
    {
        return "XRealmAppBundle:Includes:footer_navigation.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
