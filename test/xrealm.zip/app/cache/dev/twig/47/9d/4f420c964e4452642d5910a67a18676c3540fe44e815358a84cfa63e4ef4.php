<?php

/* XRealmAppBundle:Pages:login.html.twig */
class __TwigTemplate_479d4f420c964e4452642d5910a67a18676c3540fe44e815358a84cfa63e4ef4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        try {
            $this->parent = $this->env->loadTemplate("XRealmAppBundle:Includes:base_layout.html.twig");
        } catch (Twig_Error_Loader $e) {
            $e->setTemplateFile($this->getTemplateName());
            $e->setTemplateLine(1);

            throw $e;
        }

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "XRealmAppBundle:Includes:base_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        $this->env->getExtension('form')->renderer->setTheme((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), array(0 => "XRealmAppBundle:Form:fields.html.twig"));
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_content($context, array $blocks = array())
    {
        // line 5
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 6
            echo "    <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array())), "html", null, true);
            echo "</div>
";
        }
        // line 8
        if ((isset($context["createdMessage"]) ? $context["createdMessage"] : $this->getContext($context, "createdMessage"))) {
            // line 9
            echo "<h3>Ihr Account wurde erstellt.</h3>
<hr />
";
        }
        // line 12
        echo "<div class=\"row\">
\t<div class=\"col-sm-5 col-lg-4 col-md-5 panel panel-info\">
\t\t<h2 class=\"banner\">";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("headline.login"), "html", null, true);
        echo "</h2>
\t\t<form action=\"";
        // line 15
        echo $this->env->getExtension('routing')->getPath("login_check");
        echo "\" method=\"post\">
\t\t\t<div class=\"form-group\">
\t\t\t\t<label for=\"username\">";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("form.username.label"), "html", null, true);
        echo ":</label>
\t\t\t\t<input type=\"text\" class=\"form-control\" id=\"username\" name=\"_username\" placeholder=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("form.username.placeholder"), "html", null, true);
        echo "\" value=\"";
        echo twig_escape_filter($this->env, ((array_key_exists("last_username", $context)) ? (_twig_default_filter((isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "")) : ("")), "html", null, true);
        echo "\" />
\t\t\t</div>

\t\t\t<div class=\"form-group\">
\t\t\t\t<label for=\"password\">";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("form.password_login.label"), "html", null, true);
        echo ":</label>
\t\t\t\t<input type=\"password\" class=\"form-control\" id=\"password\" name=\"_password\" placeholder=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("form.password_login.placeholder"), "html", null, true);
        echo "\" />
\t\t\t</div>
\t\t\t";
        // line 30
        echo "
\t\t\t<button type=\"submit\" class=\"btn btn-primary pull-right\">";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("form.button.login"), "html", null, true);
        echo "</button>
\t\t</form>
\t</div>
\t";
        // line 34
        if ( !(isset($context["createdMessage"]) ? $context["createdMessage"] : $this->getContext($context, "createdMessage"))) {
            // line 35
            echo "\t<div class=\"col-lg-2 visible-lg visible-xs\">
\t\t<div class=\"visible-lg\" style=\"height: 80px\"></div>
\t\t<div class=\"info-circle\">";
            // line 37
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("form.string.or"), "html", null, true);
            echo "</div>
\t</div>
\t<div class=\"col-sm-6 col-lg-6 panel panel-info col-sm-offset-1 col-md-offset-1 col-lg-offset-0\">
\t\t<h2 class=\"banner\">";
            // line 40
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("headline.register"), "html", null, true);
            echo "</h2>
\t\t";
            // line 41
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
            echo "
\t</div>
\t";
        }
        // line 44
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "XRealmAppBundle:Pages:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  123 => 44,  117 => 41,  113 => 40,  107 => 37,  103 => 35,  101 => 34,  95 => 31,  92 => 30,  87 => 23,  83 => 22,  74 => 18,  70 => 17,  65 => 15,  61 => 14,  57 => 12,  52 => 9,  50 => 8,  44 => 6,  42 => 5,  39 => 4,  35 => 1,  33 => 2,  11 => 1,);
    }
}
