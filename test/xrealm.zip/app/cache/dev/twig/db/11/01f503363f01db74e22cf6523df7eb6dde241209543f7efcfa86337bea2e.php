<?php

/* XRealmAppBundle:Form:fields.html.twig */
class __TwigTemplate_db1101f503363f01db74e22cf6523df7eb6dde241209543f7efcfa86337bea2e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'form_widget' => array($this, 'block_form_widget'),
            'form_row' => array($this, 'block_form_row'),
            'form_errors' => array($this, 'block_form_errors'),
            'form_label' => array($this, 'block_form_label'),
            'button_label' => array($this, 'block_button_label'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $this->displayBlock('form_widget', $context, $blocks);
        // line 9
        $this->displayBlock('form_row', $context, $blocks);
        // line 21
        $this->displayBlock('form_errors', $context, $blocks);
        // line 33
        $this->displayBlock('form_label', $context, $blocks);
        // line 57
        $this->displayBlock('button_label', $context, $blocks);
    }

    // line 1
    public function block_form_widget($context, array $blocks = array())
    {
        // line 2
        if ((isset($context["compound"]) ? $context["compound"] : $this->getContext($context, "compound"))) {
            // line 3
            $this->displayBlock("form_widget_compound", $context, $blocks);
        } else {
            // line 5
            $this->displayBlock("form_widget_simple", $context, $blocks);
        }
    }

    // line 9
    public function block_form_row($context, array $blocks = array())
    {
        // line 10
        echo "<div class=\"form-group";
        if ((isset($context["errors"]) ? $context["errors"] : $this->getContext($context, "errors"))) {
            echo " has-error has-feedback";
        }
        echo "\">";
        // line 11
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'label');
        // line 13
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget', array("attr" => array("class" => "form-control")));
        // line 14
        if ((isset($context["errors"]) ? $context["errors"] : $this->getContext($context, "errors"))) {
            // line 15
            echo "\t\t<span class=\"form-control-feedback\" aria-hidden=\"true\"><i class=\"icon icon-times\"></i></span>
\t\t";
        }
        // line 17
        echo "    </div>";
        // line 18
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
    }

    // line 21
    public function block_form_errors($context, array $blocks = array())
    {
        // line 22
        ob_start();
        // line 23
        echo "    <span class=\"help-inline\">
        ";
        // line 24
        if ((twig_length_filter($this->env, (isset($context["errors"]) ? $context["errors"] : $this->getContext($context, "errors"))) > 0)) {
            // line 25
            echo "            ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["errors"]) ? $context["errors"] : $this->getContext($context, "errors")));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 26
                echo "                <p class=\"text-danger\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute($context["error"], "messageTemplate", array())), "html", null, true);
                echo "</p>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 28
            echo "        ";
        }
        // line 29
        echo "    </span>
";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
    }

    // line 33
    public function block_form_label($context, array $blocks = array())
    {
        // line 34
        if ( !((isset($context["label"]) ? $context["label"] : $this->getContext($context, "label")) === false)) {
            // line 35
            if ( !(isset($context["compound"]) ? $context["compound"] : $this->getContext($context, "compound"))) {
                // line 36
                $context["label_attr"] = twig_array_merge((isset($context["label_attr"]) ? $context["label_attr"] : $this->getContext($context, "label_attr")), array("for" => (isset($context["id"]) ? $context["id"] : $this->getContext($context, "id"))));
            }
            // line 38
            echo "        ";
            if ((isset($context["required"]) ? $context["required"] : $this->getContext($context, "required"))) {
                // line 39
                $context["label_attr"] = twig_array_merge((isset($context["label_attr"]) ? $context["label_attr"] : $this->getContext($context, "label_attr")), array("class" => trim(((($this->getAttribute((isset($context["label_attr"]) ? $context["label_attr"] : null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute((isset($context["label_attr"]) ? $context["label_attr"] : null), "class", array()), "")) : ("")) . " required"))));
            }
            // line 41
            echo "        ";
            if (twig_test_empty((isset($context["label"]) ? $context["label"] : $this->getContext($context, "label")))) {
                // line 42
                if ( !twig_test_empty((isset($context["label_format"]) ? $context["label_format"] : $this->getContext($context, "label_format")))) {
                    // line 43
                    $context["label"] = strtr((isset($context["label_format"]) ? $context["label_format"] : $this->getContext($context, "label_format")), array("%name%" =>                     // line 44
(isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "%id%" =>                     // line 45
(isset($context["id"]) ? $context["id"] : $this->getContext($context, "id"))));
                } else {
                    // line 48
                    $context["label"] = $this->env->getExtension('form')->humanize((isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")));
                }
            }
            // line 51
            echo "<label";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["label_attr"]) ? $context["label_attr"] : $this->getContext($context, "label_attr")));
            foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                echo " ";
                echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                echo "\"";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">
\t\t\t";
            // line 52
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans((isset($context["label"]) ? $context["label"] : $this->getContext($context, "label"))), "html", null, true);
            echo ":";
            if ((isset($context["required"]) ? $context["required"] : $this->getContext($context, "required"))) {
                echo "*";
            }
            // line 53
            echo "\t\t\t</label>";
        }
    }

    // line 57
    public function block_button_label($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "XRealmAppBundle:Form:fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  164 => 57,  159 => 53,  153 => 52,  137 => 51,  133 => 48,  130 => 45,  129 => 44,  128 => 43,  126 => 42,  123 => 41,  120 => 39,  117 => 38,  114 => 36,  112 => 35,  110 => 34,  107 => 33,  101 => 29,  98 => 28,  89 => 26,  84 => 25,  82 => 24,  79 => 23,  77 => 22,  74 => 21,  70 => 18,  68 => 17,  64 => 15,  62 => 14,  60 => 13,  58 => 11,  52 => 10,  49 => 9,  44 => 5,  41 => 3,  39 => 2,  36 => 1,  32 => 57,  30 => 33,  28 => 21,  26 => 9,  24 => 1,);
    }
}
