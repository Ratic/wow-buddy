<?php

namespace XRealm\AppBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class XRealmAppBundle extends Bundle
{
}
