<?php

namespace XRealm\AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class IndexController extends Controller
{
    public function indexAction()
    {
        return $this->render('XRealmAppBundle:Pages:index.html.twig');
    }
}
