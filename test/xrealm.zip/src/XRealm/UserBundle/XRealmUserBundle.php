<?php

namespace XRealm\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class XRealmUserBundle extends Bundle
{
}
